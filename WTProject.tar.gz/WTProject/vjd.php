<?php

session_start();
$w=$_SESSION["emaail"];


echo " <a href='logout.php'><button type='button' class='d3' >LOGOUT</button></a>";
echo "<u>logged in as </u>"."<u><b>$w</b></u>";

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <link rel="stylesheet" href="login.css">
        <script src="register.js" >
       </script>
       <style>
            button.d3
            {
                position:relative;
                left:1090px;
                top:0px;
            }
        </style>
    <title>hi blood donar!</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body background="4.jpg">
    <center>
        <h1 class="b1"><img src="blood1.png" width="200px" height="150px" >
                Blood Donars</h1>
    </center>
    <br><br>
    <marquee><b><font size="5" color="green">The List Of Our Blood Banks in Vijayawada</font></b></marquee>
    <br><br>
    <center>
        <font size="5"><b> General  Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> Ground Floor, Government General Hospital Premises, Vijayawada<br>
        <b>Contact:</b> 0866 2452244, 0866 2452844<br>
    </p>
    <font size="5"><b>Lions Blood Bank (Lions Vijayawada Vision Multiservice Trust)</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b> Address:</b> Door No. 29-19-85, First Floor, & Second Floor, Old Janata Hospital Building, Dornakol Road,Vijayawada<br>
        <b>Contact:</b> 9392120187<br>
    </p>
    <font size="5"><b>Indian Red Cross Society Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> Near District Area Hospital,Vijayawada<br>
        <b>Website:</b> Http://Www.Indianredcross.Org<br>
    </p>
    <font size="5"><b>Sri Satya Sai Institute Of Higher Medical Sciences Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> Near Cyber Towers of Prasanthigram,Vijayawada<br>
            <b>Contact:</b> 08555 287900, 08555 287388, 08555 287554<br>
    </p>
    <font size="5"><b>Arogyavaram Medical Centre Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> Ground Floor, D.No. 16-1, Bartons Laboratory, AMC Sanitorium, Arogyavaram,Vijayawada<br>
        <b>Contact:</b>08555 287922, 08555 287845<br>
    </p>
    <font size="5"><b>District Head Quarter Hospital Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> 1st Floor, District Head Quarter Hospital Premises,Vijayawada<br>
        <b>Contact:</b> 08572 22087<br>
    </p>
    <font size="5"><b>Sri Venkata Sai Charitable Trust Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> H. No. 10-3-206, M4, First Floor, Reddy & Reddy Colony, Varadaraja Nagar,Vijayawada<br>

        <b>Contact:</b> 0877 6667671<br>
    </p>
    <font size="5"><b>Sri Venkateswara Institute Of Medical Sciences Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b> Address:</b> Sri Venkateswara Institute Of Medical Sciences Hospital Premises,Vijayawada<br>
        <b>Contact:</b> 0877 2287777<br>
    </p>
    <font size="5"><b>Svrr Government General Hospital Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> 1st Floor, Main Building, SSVR Hosital Permises, Vijayawada<br>
        <b>Contact:</b> 08771 2286666<br>
    </p>
    <font size="5"><b>Ariaria Blood Bank</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> 1st Floor, District Hospital Premises,Vijawada<br>
        <b>Contact:</b> 0866 2440044, 0883 2428555<br>
    </p>
    <font size="5"><b>Gsl Medical College And General Hospital Blood Bank
</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> Laxmipuram, NH.5, Rajanagaram Mandal, Vijayawada<br>
        <b>Contact:</b> 0883 2484999<br>
    </p>
    <font size="5"><b>Jagruti Charitable Trust Blood Bank
</b></font>
    <hr align="center" width="25%" color="purple">
    <p>
        <b>Address:</b> D.No. 77-1-2, 1st Floor, Jagruthi Building, Vijayawada<br>
        <b>Contact:</b> 0883 2443612<br>
    </p>
    </center>