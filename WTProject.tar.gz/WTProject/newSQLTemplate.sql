/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  adithyakng
 * Created: 30 Mar, 2018
 */

select * from test.blooddonar;
delete from test.blooddonar;